const e=`{
  "projectId": "rakib-8cc2a",
  "appId": "1:1096544082404:web:b158f6f2c5ccc7eef80ff1",
  "apiKey": "AIzaSyC_GmwisMWJX_ONOXXO6O-2VrSc8ArUYdU",
  "authDomain": "rakib-8cc2a.firebaseapp.com",
  "firestoreDatabaseId": "(default)",
  "storageBucket": "rakib-8cc2a.firebasestorage.app",
  "messagingSenderId": "1096544082404",
  "measurementId": "G-SZPL053YD7"
}
`;export{e as default};
